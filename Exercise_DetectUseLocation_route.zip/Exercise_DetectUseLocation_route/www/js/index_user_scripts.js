/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Button */
    $(document).on("click", ".uib_w_3", function(evt)
    {
        /* your code goes here */ 
         GMaps.geolocate({
            success: function (position) {
                 var lat = position.coords.latitude;
                 var lng = position.coords.longitude;
                
                 var map = new GMaps ({
                    div: '#map',
                    lat: lat,
                    lng: lng
                });
                map.setZoom(8);
                
                 map.addMarker({
                    lat: lat,
                    lng: lng,
                    infoWindow: {
                        content: '<b> <i> You are here! </i></b>'
                    }
                });
                
                 map.addMarker({
                    lat: 6.46815,
                    lng: 100.50706,
                    
                    infoWindow: {
                        content: '<b> <i> This is my home </i></b>'
                    }
                });
                
                map.drawRoute({
                    origin: [lat, lng], //detect User location
                    destination: [6.46815, 100.50706], //Your house
                    travelMode: 'driving',
                    strokeColor: '#FF0000',
                    strokeOpacity: 0.6,
                    strokeWeight: 6
                });
                
            },
            error: function (error)  {
             alert("Error in Your Geolocation. Try again.");
         }
            });
         return false;
    });
    
        /* button  .uib_w_5 */
    $(document).on("click", ".uib_w_5", function(evt)
    {
        /* your code goes here */ 
        GMaps.geocode({
            address: $('#place').val(),
            callback: function (results, status) {
                if (status == 'OK'){
                    //alert("result: " + JSON.stringify(results));
                    var latLng = results[0].geometry.location;
                    var lat = latLng.lat();
                    var lng = latLng.lng();
                    alert("result: " +lat);
                    var map = new GMaps ({
                        div: '#map',
                        lat: lat,
                        lng: lng
                    });
                    
                    GMaps.createPanorama ({
                    el: '#imag',
                    lat: lat,
                    lng: lng
                    });
                    
                    map.addMarker({
                       lat: lat,
                        lng: lng,
                        infoWindow: {
                        content: '<b> <i> You are here! </i></b>'
                    }
                    });
                    
                    map.addMarker({
                    lat: 6.46815,
                    lng: 100.50706,
                    
                    infoWindow: {
                        content: '<b> <i> This is my home </i></b>'
                    }
                });
                    map.drawRoute({
                    origin: [lat, lng], //detect from the textbox
                    destination: [6.46815, 100.50706], //Your house
                    travelMode: 'driving',
                    strokeColor: '#FF0000',
                    strokeOpacity: 0.6,
                    strokeWeight: 6
                });

                    
                }
            }
        });
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
