/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  .uib_w_3 */
    $(document).on("click", ".uib_w_3", function(evt)
    {
        /* your code goes here */ 
        
        var map = new GMaps ({
            div: '#map',
            lat: 6.1525,
            lng: 102.3063
        });
        
        map.addMarker({
            lat: 6.1525,
            lng: 102.3063,
            
            infoWindow: {
                content: '<b><i> Pengkalan Chepa, Kelantan</i><b>'
            }
        });
         return false;
    });
    
        /* button  .uib_w_4 */
    $(document).on("click", ".uib_w_4", function(evt)
    {
        /* your code goes here */ 
        GMaps.geolocate({
            success: function (position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                alert("Your current positon: (" + lat + "," +lng +")");
                
                 var map = new GMaps ({
                div: '#map',
                lat: lat,
                lng: lng
                    });
                
                map.addMarker({
                lat:lat,
                lng: lng,
                infoWindow: {
                content: '<b><i> You are here! </i><b>'
                        }
                    });
            },
            
            error: function (error) {
                alert("Error in your Geolaoction. Try again.");
            }
        });
        
        
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
