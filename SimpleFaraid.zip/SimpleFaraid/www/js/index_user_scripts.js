/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Calc Simple Faraid */
    $(document).on("click", ".uib_w_5", function(evt)
    {
        /* your code goes here */ 
   
        
       var inp_wealth =document.getElementById("wealth").value;
       var inp_son =document.getElementById("son").value;
       var inp_daughter =document.getElementById("daughter").value;
        
        if(inp_son && inp_daughter >= 0){
            var son_share = 2*inp_son;
            var daughter_share = 1*inp_daughter;
            var all_share= son_share + daughter_share;
            var hus = 0.25;
            var wife = 0.125;
            var mum = 0.17;
            var dad = 0.17;
            
            all();
            
            
            
        //}else if(inp_daughter > 0 && inp_son = 0){
            
        //}else if(inp_son > 0 && inp_daughter = 0){
            
        }else{
            
        }
        
        
        function all(){
                
                var s=(son_share / all_share) * inp_wealth;
                var d=(daughter_share / all_share) * inp_wealth;
                var h=(hus*inp_wealth);
                var w=(wife*inp_wealth);
                var m=(mum*inp_wealth);
                var da=(dad*inp_wealth);
                document.getElementById("ans").innerHTML = "Answer Area: <b>" +" Son: " +s.toFixed(0)+" Daughter: " +d.toFixed(0) +" Husband: " +h.toFixed(0) +" Wife: " +w.toFixed(0) +" Mother: " +m.toFixed(0) +" Father: " +da.toFixed(0);
                

            }
    

        //document.getElementById("ans").innerHTML = "Answer Area: <b>" +inp_wealth +"<b>";
         
        
        
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
