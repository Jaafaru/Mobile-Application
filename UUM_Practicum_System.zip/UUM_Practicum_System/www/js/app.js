//SETTING
domain ='ibidathoillah.esy.es';
//domain ='localhost';
localStorage.setItem("domain", domain);

angular.module('ionicApp', ['ionic'])

.controller('AppCtrl', function() {

  ionic.Platform.ready(function() {
    navigator.splashscreen.hide();
});

});

function imgError(image) {
  image.onerror = "";
  image.src = "img/user64.png";
  return true;
}

angular.module('ionicApp', ['ionic'])
.controller('AppCtrl', function ($scope, $ionicSideMenuDelegate, $ionicPopup,$ionicLoading, $timeout) {
    io = $ionicPopup;
    il = $ionicLoading;
    $scope.toggleLeft = function () {
        $ionicSideMenuDelegate.toggleLeft();
    };
    il.show({
                template: '<ion-spinner icon="lines"></ion-spinner><br>Gathering information...',
                duration: 8000
            }).then(function () {

            });
    $scope.doRefresh = function () {
     location.reload();
    };
    
  
});

function alert(text){
 var alertPopup = io.alert({
   title: text
});
}

  var keren = null;

    document.addEventListener("deviceready", function () {
        if (!localStorage.getItem("rp_data")) {
            var rp_data = {
                data: []
            };
            localStorage.setItem("rp_data", JSON.stringify(rp_data));
        }

        keren = JSON.parse(localStorage.getItem("rp_data"));
    }, false);

        function schedule(id, title, message, schedule_time) {
            cordova.plugins.notification.local.schedule({
                id: id,
                title: title,
                message: message,
                at: schedule_time
            });

            var array = [id, title, message, schedule_time];
            keren.data[keren.data.length] = array;
            localStorage.setItem("rp_data", JSON.stringify(keren));

           // navigator.notification.alert("Reminder added successfully")
        }

function strip(html)
		{
			   var tmp = document.createElement("DIV");
			   tmp.innerHTML = html;
			   return tmp.textContent || tmp.innerText || "";
		}

            


