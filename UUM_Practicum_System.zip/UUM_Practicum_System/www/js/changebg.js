
if(localStorage.getItem("access")=="student")
{
	$('ion-content').attr("style","background:lightblue !important");
}
else if(localStorage.getItem("access")=="lecture")
{
	$('ion-content').attr("style","background:yellow !important");
}
else
{

}
  
  document.onreadystatechange = function () {
        var state = document.readyState;
        if (state == 'interactive') {
        document.getElementsByTagName("BODY")[0].style.visibility = "hidden";




        } else if (state == 'complete') {

            il.hide().then(function () {

                document.getElementById('interactive');
              document.getElementsByTagName("BODY")[0].style.visibility = "visible";

            });
            setTimeout(function () {



            }, 500);
        }
    }
  