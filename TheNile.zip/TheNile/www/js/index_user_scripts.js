/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
        
    
        /* graphic button  #Getstarted */
    $(document).on("click", "#Getstarted", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginPage"); 
         return false;
    });
        
    
        /* button  #FYPbutton */
    $(document).on("click", "#FYPbutton", function(evt)
    {
         /*global activate_page */
         activate_page("#Forget-password-page"); 
         return false;
    });
        
    
        /* button  #BackSingup */
    $(document).on("click", "#BackSingup", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginPage"); 
         return false;
    });
    
    
        /* button  #Back-Analytics */
    $(document).on("click", "#Back-Analytics", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Logout-Button */
    $(document).on("click", "#Logout-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginPage"); 
         return false;
    });

        /* button  #BackForgot */
    $(document).on("click", "#BackForgot", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginPage"); 
         return false;
    });
    
        /* button  #Setting */
    $(document).on("click", "#Setting", function(evt)
    {
         /*global activate_page */
         activate_page("#Setting-page"); 
         return false;
    });
    
        /* button  #BackNote */
    $(document).on("click", "#BackNote", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #BackManage */
    $(document).on("click", "#BackManage", function(evt)
    {
         /*global activate_page */
         activate_page("#Setting-page"); 
         return false;
    });
    
        /* button  #back-setting */
    $(document).on("click", "#back-setting", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Note */
    $(document).on("click", "#Note", function(evt)
    {
         /*global activate_page */
         activate_page("#Add-Note-Page"); 
         return false;
    });
    
        /* button  #MyprofileSetting */
    $(document).on("click", "#MyprofileSetting", function(evt)
    {
         /*global activate_page */
         activate_page("#Manage-Profile"); 
         return false;
    });
    
    
    /* button  #CreateSignUp */
    $(document).on("click", "#CreateSignUp", function(evt)
    {
         /*global activate_page */
    var data = $("#role,#username,#matric,#email,#password,#confirmpassword,#gender,#dateofbirth").serialize();
            var url = "http://localhost/thenile/user.php";
            $.ajax({
                type: "POST",
                url: url,
                data: data,

            success: function (result) {
                alert("Successfully Register");

            },
            error: function (jqXHR, status, thrown) {
                alert("Status msj:" + status +
                    "\nThrown msj: " + thrown);
                alert(JSON.stringify(jqXHR));

            }
    });
        return false;
    });
    
    
        /* button  #Back-Support */
    $(document).on("click", "#Back-Support", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Update */
    $(document).on("click", "#Update", function(evt)
    {
         /*global activate_page */
         activate_page("#Setting-page"); 
         return false;
    });
    
        /* button  #Back-Analytics */
    $(document).on("click", "#Back-Analytics", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Support */
    $(document).on("click", "#Support", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* button  #Back-advisor */
    $(document).on("click", "#Back-advisor", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Back-advisor-details */
    $(document).on("click", "#Back-advisor-details", function(evt)
    {
         /*global activate_page */
         activate_page("#Connect-with-advisors"); 
         return false;
    });
        
    
        /* button  #Back About */
    $(document).on("click", "#Back About", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* button  #Back Help */
    $(document).on("click", "#Back Help", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* button  About */
    $(document).on("click", ".uib_w_118", function(evt)
    {
         /*global activate_page */
         activate_page("#About-Page"); 
         return false;
    });
    
        /* button  Help */
    $(document).on("click", ".uib_w_119", function(evt)
    {
         /*global activate_page */
         activate_page("#Help-Page"); 
         return false;
    });
    
        /* button  #Home-Button */
    $(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Home-Button */
    $(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Home-Button */
    $(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Home-Button */
$(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Home-Button */
    $(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Home-Button */
    $(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Back-About */
    $(document).on("click", "#Back-About", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* button  #Back-Help */
    $(document).on("click", "#Back-Help", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* button  #Back-Stress */
    
    
        /* button  #Back-Therapy */
    $(document).on("click", "#Back-Therapy", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* graphic button  #Therapy */
    $(document).on("click", "#Therapy", function(evt)
    {
         /*global activate_page */
         activate_page("#Therapy_Page"); 
         return false;
    });
    
        /* graphic button  #Advisors */
    $(document).on("click", "#Advisors", function(evt)
    {
         /*global activate_page */
         activate_page("#Connect-with-advisors"); 
         return false;
    });
    
        
        /* button  #Home */
    $(document).on("click", "#Home", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
        
    
        /* button  #Back_feedback */
    $(document).on("click", "#Back_feedback", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* graphic button  #StressAnalytics */
    $(document).on("click", "#StressAnalytics", function(evt)
    {
         /*global activate_page */
         activate_page("#Analytics-Page"); 
         return false;
    });
    
        /* button  #Feedback */
    $(document).on("click", "#Feedback", function(evt)
    {
         /*global activate_page */
         activate_page("#Feedback_Page"); 
         return false;
    });
        
    
        /* button  #Back-advice */
    $(document).on("click", "#Back-advice", function(evt)
    {
         /*global activate_page */
         activate_page("#Advisor-Login-Page"); 
         return false;
    });
    
        /* button  #Setting */
    $(document).on("click", "#Setting", function(evt)
    {
         /*global activate_page */
         activate_page("#Setting-page"); 
         return false;
    });
    
        /* button  #Support-advisor */
    $(document).on("click", "#Support-advisor", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
        /* button  #Note-advisor */
    $(document).on("click", "#Note-advisor", function(evt)
    {
         /*global activate_page */
         activate_page("#note-advisor-page"); 
         return false;
    });
    
        /* button  #Logout-advisor */
    $(document).on("click", "#Logout-advisor", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginPage"); 
         return false;
    });
    
    
    
        /* button  #CreateAccount */
    $(document).on("click", "#CreateAccount", function(evt)
    {
         /*global activate_page */
         activate_page("#SignUp"); 
         return false;
    });
    
        /* button  #Support-student */
    $(document).on("click", "#Support-student", function(evt)
    {
         /*global activate_page */
         activate_page("#Support-Page"); 
         return false;
    });
    
    
        /* button  #First */
    $(document).on("click", "#First", function(evt)
    {
         /*global activate_page */
         activate_page("#Advisor1-Page"); 
         return false;
    });
    
        /* button  #Second */
    $(document).on("click", "#Second", function(evt)
    {
         /*global activate_page */
         activate_page("#Advisor1-Page"); 
         return false;
    });
    
        /* button  #Third */
    $(document).on("click", "#Third", function(evt)
    {
         /*global activate_page */
         activate_page("#Advisor1-Page"); 
         return false;
    });
    
        /* button  #Anxiety */
    $(document).on("click", "#Anxiety", function(evt)
    {
         /*global activate_page */
         activate_page("#Stress-analytics"); 
         return false;
    });
    
        /* button  Stress */
    
    
        /* button  #Home-Button */
    $(document).on("click", "#Home-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#Students-Login"); 
         return false;
    });
    
        /* button  #Stress */
    $(document).on("click", "#Stress", function(evt)
    {
         /*global activate_page */
         activate_page("#Stress-analytics"); 
         return false;
    });
    
        /* button  General Well-Being */
    $(document).on("click", ".uib_w_139", function(evt)
    {
         /*global activate_page */
         activate_page("#Stress-analytics"); 
         return false;
    });
    
        

        
    
    
        /* graphic button  #login */
    $(document).on("click", "#login", function(evt)
    {
                var login = $("#loginas").val();
                var name = document.getElementById("username").value;
                var password =document.getElementById("password").value;
        
                    if (login == "I am student") {
                        $.ajax({
                            type: 'POST',
                            url: "http://localhost/thenile/login.php",
                            data: 'username=' + name + '&password=' + password,
                            success: function (msg) {
                    if (msg == "1") {
        activate_page("#Students-Login"); 
                    } else {
                    alert("The username or password you entered is incorrect.");
                    }

                }
            });
             }  else if (login == "I am advisor") {
                        $.ajax({
                            type: 'POST',
                            url: "http://localhost/thenile/advisorlogin.php",
                            data: 'username=' + name + '&password=' + password,
                            success: function (msg) {
                    if (msg == "1") {
        activate_page("#Advisor-Login-Page"); 
                    } else {
                    alert("The username or password you entered is incorrect.");
                    }

                }
            });
             }
         return false;
    });
    
        /* button  #login1 */
    $(document).on("click", "#login1", function(evt)
    {
         /*global activate_page */
         activate_page("#LoginPage"); 
         return false;
    });
    
        /* button  #post-advice  */
    $(document).on("click", "#post-advice ", function(evt)
    {
         /*global activate_page */
         activate_page("#note-advisor-page"); 
         return false;
    });
    
        /* button  #back-status */
    $(document).on("click", "#back-status", function(evt)
    {
         /*global activate_page */
         activate_page("#Advisor-Login-Page"); 
         return false;
    });
    
        /* button  #advisor-home */
    $(document).on("click", "#advisor-home", function(evt)
    {
         /*global activate_page */
         activate_page("#Advisor-Login-Page"); 
         return false;
    });
    
        /* button  #back-student-status */
    $(document).on("click", "#back-student-status", function(evt)
    {
         /*global activate_page */
         activate_page("#student-status-page"); 
         return false;
    });
    
        /* button  Contact with the student */
    $(document).on("click", ".uib_w_226", function(evt)
    {
         /*global activate_page */
         activate_page("#Student-details-page"); 
         return false;
    });
    
        /* button  #check-student-status */
    $(document).on("click", "#check-student-status", function(evt)
    {
         /*global activate_page */
         activate_page("#student-status-page"); 
         return false;
    });
    
        /* button  #Back-Stress */
    $(document).on("click", "#Back-Stress", function(evt)
    {
         /*global activate_page */
         activate_page("#Analytics-Page"); 
         return false;
    });
    
        /* button  #BackCBT */
    $(document).on("click", "#BackCBT", function(evt)
    {
         /*global activate_page */
         activate_page("#Therapy_Page"); 
         return false;
    });
    
        /* button  #Back-MFT */
    $(document).on("click", "#Back-MFT", function(evt)
    {
         /*global activate_page */
         activate_page("#Therapy_Page"); 
         return false;
    });
    
        /* button  #Back-DBT */
    $(document).on("click", "#Back-DBT", function(evt)
    {
         /*global activate_page */
         activate_page("#Therapy_Page"); 
         return false;
    });
    
        /* graphic button  #CBT-Button */
    $(document).on("click", "#CBT-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#CBT-Page"); 
         return false;
    });
    
        /* graphic button  #MFT-Button */
    $(document).on("click", "#MFT-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#MFT"); 
         return false;
    });
    
        /* graphic button  #DBT-Button */
    $(document).on("click", "#DBT-Button", function(evt)
    {
         /*global activate_page */
         activate_page("#DBT"); 
         return false;
    });
    
        /* button  #Back-CBT */
    $(document).on("click", "#Back-CBT", function(evt)
    {
         /*global activate_page */
         activate_page("#Therapy_Page"); 
         return false;
    });
        
    
        /* button  #Back-reset */
    $(document).on("click", "#Back-rest", function(evt)
    {
         /*global activate_page */
         activate_page("#Forget-password-page"); 
         return false;
    });
    

        /* button  #Submit-Ana */
    $(document).on("click", "#Submit-Ana", function(evt)
    {
        /* your code goes here */ 
         return false;
    });

    
        /* button  #submit_fog */
    $(document).on("click", "#submit_fog", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
    
    }
                   
document.addEventListener("app.Ready", register_event_handlers, false);
})();
