/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Button */
    $(document).on("click", ".uib_w_5", function(evt)
    {
        /* your code goes here */ 
        var latlng;
         var map = googleMaps.getObjectBySelector("#canvas_map");
        var locate = $("#input1").val();
        var url1 = "https://maps.googleapis.com/maps/api/geocode/json?address=" +locate;
        $.ajax({
            async:false,
            url: url1,
            success: function (result) {
                alert("from ajax1");
                var lat = result.results[0].geometry.location.lat;
                var lng = result.results[0].geometry.location.lng;
                alert("Lat-lng: (" + lat + "," + lng + ")");
                
                 latlng = new google.maps.LatLng(lat, lng);
                map.setCenter(latlng);
                map.setZoom(6);
                
                var markerId = new google.maps.Marker({
                position: latlng,
                map: map
                });
            var infoBox = new google.maps.InfoWindow({
            content: locate
                });
            infoBox.open(map, markerId);
            
            },
            
            error: function (a, b, status) {
                alert("Error occur: " +status);
            }
        });
        
        
        
        var latlng2;
        var locate2 = $("#input2").val();

         var url2 = "https://maps.googleapis.com/maps/api/geocode/json?address=" +locate2;
        $.ajax({
            async:false,
            url: url2,
            success: function (result) {
                alert("from ajax2");
                var lat = result.results[0].geometry.location.lat;
                var lng = result.results[0].geometry.location.lng;
                alert("Lat-lng: (" + lat + "," + lng + ")");
                
                latlng2 = new google.maps.LatLng(lat, lng);
                map.setCenter(latlng2);
               
                
                var markerId2 = new google.maps.Marker({
                position: latlng2,
                map: map
                });
            var infoBox2 = new google.maps.InfoWindow({
            content: locate2
                });
            infoBox2.open(map, markerId2);
            
            },
            
            error: function (a, b, status) {
                alert("Error occur: " +status);
            }
        });
        
        var thePath = [latlng, latlng2];
        var garis = new google.maps.Polyline({
            path: thePath,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 2
        });
        
        garis.setMap(map);
        
        
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
