/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Button */
    $(document).on("click", ".uib_w_3", function(evt)
    {
        /* your code goes here */ 
        
        GMaps.geolocate({
            success: function (position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                alert("Your lat-lng (" + lat + "," + lng + ")");
                
                var map = new GMaps({
                    div: '#map',
                    lat: lat,
                    lng: lng
                });
                
                map.addMarker({
                    lat: lat,
                    lng: lng,
                    infoWindow: {
                        content: '<b> <i> You are here! </i></b>'
                    }
                });
                
                var strURL = "My Lat-Lng is (" + lat + "," + lng + ")";
                var msg = encodeURIComponent(strURL);
                var whatsapp_url = "whatsapp://send?text=" + msg;
                var strHREF = "<a class='btn btn-info' role='button' href='" + whatsapp_url + "'>Click here to share your location</a>";
                //alert(strHREF);
                $("#output").html(strHREF);
            },
            error: function (error) {
                alert("Error in Your Geolocation. Try again.");
            }
        });
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
