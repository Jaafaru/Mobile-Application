/** Automatically generated file. DO NOT MODIFY */
package com.soc.friendlist3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}