package com.soc.friendlist3;

import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	SQLiteDatabase dbf = null;
	private static String DBName = "dbtest";
	EditText fname,sname,fmatric,faddress,fcol;
    Spinner fnation;
    ListView flist;
    ArrayList<String> results,metric;
	Button btn;
	int clicked=-1;

    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
     	
        
        ListView listView1 = (ListView) findViewById(R.id.list1);
        fname = (EditText) findViewById(R.id.editText1);
		sname =(EditText) findViewById(R.id.editText2);
		fmatric = (EditText) findViewById(R.id.editText3);
		faddress =(EditText) findViewById(R.id.editText4);
		fcol =(EditText) findViewById(R.id.editText5);
		fnation =(Spinner) findViewById(R.id.spinner1);
	    flist =(ListView) findViewById(R.id.list1);
	   
	    Button bu = (Button) findViewById(R.id.button3);
	    addListenerOnButton();
		dbf = this.openOrCreateDatabase(DBName, MODE_PRIVATE, null);
		
        
      //Write spinner and arrayAdapter for list the String stored in array 
        final Spinner spinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(
        this, R.array.nation, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        
        //showData();
		listView1.setTextFilterEnabled(true);
		listView1.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position,
                    long id) {
               
            	String item = ((TextView) view).getText().toString();
            	clicked=position;
            	fname.setText(item);
            	
            }
        });
		
		bu.setOnClickListener(new OnClickListener() {


            @Override
            public void onClick(View v) {
                updatedata();
                showData();
            }


        });

		
		}

    
    public void addData(View v)
	{String name = fname.getText().toString();
	String names = sname.getText().toString();
	String matric = fmatric.getText().toString();
	String address = faddress.getText().toString();
	String college = fcol.getText().toString();
	String text = fnation.getSelectedItem().toString();
    	
    	
        try{
        	          
 
            //Create table using execSQL
            dbf.execSQL("CREATE TABLE IF NOT EXISTS friends(ID INTEGER PRIMARY KEY, NAME " 
            + "VARCHAR, SURNAME VARCHAR, MATRIC VARCHAR, ADDRESS VARCHAR, COLLEGE VARCHAR,NATIONALITY VARCHAR);");  //Declare a fill
            
            //Insert student data into table created

           dbf.execSQL("INSERT INTO friends(NAME,SURNAME,MATRIC,ADDRESS,COLLEGE,NATIONALITY) VALUES"
           + "('"+name+"', '"+names+"', '"+matric+"', '"+address+"', '"+college+"', '"+text+"');");
            Toast.makeText(getApplicationContext(), "Added Data", Toast.LENGTH_LONG).show();
            showData();
            clearText();

            
        }
        catch (Exception e ) {
        	Toast.makeText(getApplicationContext(), "Data not added!!", Toast.LENGTH_LONG).show();
        }

	}
    public void clearText()
    {
        fname.setText("");
        sname.setText("");
        fmatric.setText("");
        faddress.setText("");
        fcol.setText("");
        
    }

    
    public void deletedata(View v){
    	AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(MainActivity.this);
        myAlertDialog.setTitle("--- Delete Dialog---");
        myAlertDialog.setMessage("Do you want to delete?");
        myAlertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface arg0, int arg1) {

         	
          if (clicked!=-1){
              dbf.execSQL("DELETE FROM friends WHERE name = '"+metric.get(clicked)+"'"); 
              Toast.makeText(getApplicationContext(), "Data deleted!!", Toast.LENGTH_LONG).show();
              
              fname.setText("");
              showData();
              clicked=-1;
          }
            
            }});
    	 
        myAlertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface arg0, int arg1) {
                // do something when the Cancel button is clicked
                Toast.makeText(getApplicationContext(), "Data Not deleted!!", Toast.LENGTH_SHORT).show();
            }});
        myAlertDialog.show();

    	 
    } 

    private void showData() {
    	
    	results = new ArrayList<String>();
    	metric = new ArrayList<String>();
    	
    Cursor c = dbf.rawQuery("SELECT * FROM friends", null);
    	
    String allText = "";
    	
    	//If Cursor is valid
    	if (c != null ) {
    		//Move cursor to first row
    		if  (c.moveToFirst()) {
    			do {
    				//Get version from Cursor
    				String name1 = c.getString(c.getColumnIndex("NAME"));
    				String names1 = c.getString(c.getColumnIndex("SURNAME"));
    				String matric1 = c.getString(c.getColumnIndex("MATRIC"));
    				String address1 = c.getString(c.getColumnIndex("ADDRESS"));
    				String college1 = c.getString(c.getColumnIndex("COLLEGE"));
    				String text1 = c.getString(c.getColumnIndex("NATIONALITY"));
    				
    				allText = ""+name1+ " "+names1+" "+matric1+" "+address1+" "+college1+" "+text1;
    				results.add(allText);
    				
    				metric.add(name1);

    			}while (c.moveToNext()); //Move to next row
    		} 
    	}
    	ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
    			android.R.layout.simple_list_item_1, android.R.id.text1, results);
    	// Assign adapter to ListView
    	flist.setAdapter(adapter); 
    }
    	
    public void addListenerOnButton() {

    	final Context context = this;

    	Button button = (Button) findViewById(R.id.button4);

    	button.setOnClickListener(new OnClickListener() {


    		@Override
    		public void onClick(View v) {


    			Cursor c = dbf.rawQuery("SELECT * FROM friends WHERE MATRIC = '"+fmatric.getText().toString()
    					+"'", null);
    			if  (c.moveToFirst()) {
    				String name1 = c.getString(c.getColumnIndex("NAME"));
    				String names1 = c.getString(c.getColumnIndex("SURNAME"));
    				String address1 = c.getString(c.getColumnIndex("ADDRESS"));
    				String college1 = c.getString(c.getColumnIndex("COLLEGE"));
    				String matric1 = c.getString(c.getColumnIndex("MATRIC"));
    				String text1 = c.getString(c.getColumnIndex("NATIONALITY"));
    				Toast.makeText(getApplicationContext(),"Data found: " +name1+"  " +names1+" " +matric1+" " +address1+" " +text1+" " +college1+" ", Toast.LENGTH_LONG).show();
    				fmatric.setText("");
    			}
    			else
    				Toast.makeText(getApplicationContext(), "Data not found!!", Toast.LENGTH_LONG).show();


    		}


    	});

    }

    
    public void updatedata(){

        String name = fname.getText().toString();
        String names = sname.getText().toString();
        String matric = fmatric.getText().toString();
        String address = faddress.getText().toString();
        String college = fcol.getText().toString();
        String text = fnation.getSelectedItem().toString();


        try{
            dbf.execSQL("UPDATE friends SET NAME = '"+name+"' ,"+
                    "SURNAME = '"+names+"' , ADDRESS='"+address+"', NATIONALITY='"+text+"', COLLEGE='"+college+"' WHERE MATRIC='"+matric+"'");
            Toast.makeText(getApplicationContext(), "updated  Data", Toast.LENGTH_LONG).show();

        }
        catch (Exception e ) {
            Toast.makeText(getApplicationContext(), "Data not updated!!", Toast.LENGTH_LONG).show();
        }

    }



    
    
}
