package com.uum.soc_e_appoint;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by jaafarumusa on 06/03/16.
 */
public class Home extends AppCompatActivity implements View.OnClickListener {
    Button blogout,bset,bview,bmanage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        blogout = (Button)findViewById(R.id.blogout);
        bset =  (Button)findViewById(R.id.bset);
        bview = (Button)findViewById(R.id.bview);
        bmanage = (Button)findViewById(R.id.bmanage);

        blogout.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.blogout:
             startActivity(new Intent(this, MainActivity.class));
                break;
            
        }
    }
}
