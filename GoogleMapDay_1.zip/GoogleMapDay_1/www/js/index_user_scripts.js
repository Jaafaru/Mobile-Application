/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Show Kota Kinabalu */
    $(document).on("click", ".uib_w_3", function(evt)
    {
        /* your code goes here */ 
    
        var map = googleMaps.getObjectBySelector("#canvas_map");
        var latlngobj2 = new google.maps.LatLng(5.98136, 116.072960);
            map.setCenter(latlngobj2);
        map.setZoom(4);
        var markerId2 = new google.maps.Marker({
            position: latlngobj2,
            map: map
        });
        
        var infoBox = new google.maps.InfoWindow({
            content: "<b><i>East Malaysia</i>"
        });
        infoBox.open(map, markerId2);
        
        var latlngobj3 = new google.maps.LatLng(4.5975, 101.0901);
            map.setCenter(latlngobj3);
        
        var markerId3 = new google.maps.Marker({
            position: latlngobj3,
            map: map
        });
        var infoBox2 = new google.maps.InfoWindow({
            content: "<b><i>West Malaysia</i>"
        });
        infoBox2.open(map, markerId3);
        
        var thePath = [latlngobj2, latlngobj3];
        var garis = new google.maps.Polyline({
            path: thePath,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 2
        });
        
        garis.setMap(map);
         return false;
    });
    
        /* button  Detect my Location */
    $(document).on("click", ".uib_w_4", function(evt)
    {
        /* your code goes here */ 
        if (navigator.geolocation){
            alert("You are having geolocatiom...");
        navigator.geolocation.getCurrentPosition(function (position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;
            alert("Found your position... Lat:" + lat + "Lng:" +lng);
            
             var map = googleMaps.getObjectBySelector("#canvas_map");
            var latlng = new google.maps.LatLng(lat, lng);
            map.setCenter(latlng);
             var markerId4 = new google.maps.Marker({
            position: latlng,
            map: map
                 
                 
        });
            
        });
        }else
            alert("Not found your position...");
         return false;
    });
    
        /* button  .uib_w_5 */
    $(document).on("click", ".uib_w_5", function(evt)
    {
        /* your code goes here */ 
        var locate = $("#loc").val();
        var urlJitra = "https://maps.googleapis.com/maps/api/geocode/json?address=" +locate;
        $.ajax({
            url: urlJitra,
            success: function (result) {
                var lat = result.results[0].geometry.location.lat;
                var lng = result.results[0].geometry.location.lng;
                alert("Lat-lng: (" + lat + "," + lng + ")");
                 var map = googleMaps.getObjectBySelector("#canvas_map");
                var latlng = new google.maps.LatLng(lat, lng);
                map.setCenter(latlng);
                map.setZoom(14);
                
                var markerId = new google.maps.Marker({
                position: latlng,
                map: map
                });
            var infoBox2 = new google.maps.InfoWindow({
            content: locate
                });
            infoBox2.open(map, markerId);
            
            },
            
            error: function (a, b, status) {
                alert("Error occur: " +status);
            }
        });
        
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
