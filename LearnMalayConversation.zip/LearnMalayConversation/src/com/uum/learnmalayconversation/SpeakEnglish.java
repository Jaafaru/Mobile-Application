package com.uum.learnmalayconversation;



import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class SpeakEnglish extends Activity {
	Button btn1, btn2; 
	MediaPlayer mp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_speak_english);
		
		addListenerOnButton();
		addListenerOnButton2();
	}

	public void addListenerOnButton() { 
        btn1 = (Button) findViewById(R.id.Button1);
        btn1.setOnClickListener(new OnClickListener() {
       	 
        

        	 public void onClick(View arg0) {
            		mp = MediaPlayer.create(SpeakEnglish.this, R.raw.speak);
            		
            		mp.start();
                    
                     


}
});
	   }
	public void addListenerOnButton2() { 
	    btn2= (Button) findViewById(R.id.Button2);
	   btn2.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), Introduction.class);
	                 startActivity(intent); 

	    	 }

	   });
	}

}
