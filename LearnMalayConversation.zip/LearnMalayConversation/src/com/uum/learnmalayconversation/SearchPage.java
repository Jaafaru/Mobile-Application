package com.uum.learnmalayconversation;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SearchPage extends Activity {
	Button button1, button2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search_page);
		
		addListenerOnButton2();
		addListenerOnButton1();
	}

	 public void addListenerOnButton2() { 
		    button2= (Button) findViewById(R.id.button2);
		   button2.setOnClickListener(new OnClickListener() {
		   	 
		    

		    	 public void onClick(View arg0) {

		             Intent intent = new Intent
		                     (getApplicationContext(), MainActivity.class);
		                 startActivity(intent); 
		                
		    	 }

		   });
		}
	 
	 public void addListenerOnButton1() { 
		    button1= (Button) findViewById(R.id.button1);
		   button1.setOnClickListener(new OnClickListener() {
		   	 
		    

		    	 public void onClick(View arg0) {

		             Intent intent = new Intent
		                     (getApplicationContext(), ViewSearch.class);
		                 startActivity(intent); 
		                
		    	 }

		   });
		}
}
