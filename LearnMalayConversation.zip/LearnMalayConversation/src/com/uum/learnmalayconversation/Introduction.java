package com.uum.learnmalayconversation;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Introduction extends Activity {
    Button button1, button2, button3, button4, button5, button9;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_introduction);
		
		addListenerOnButton1();
		addListenerOnButton2() ;
		addListenerOnButton3();
		addListenerOnButton4();
		addListenerOnButton5();
		addListenerOnButton6();
	}

	public void addListenerOnButton1() { 
	    button9= (Button) findViewById(R.id.button9);
	   button9.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), SimpleSentences.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
	
	public void addListenerOnButton2() { 
	    button1= (Button) findViewById(R.id.button1);
	   button1.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), SpeakEnglish.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
	
	public void addListenerOnButton3() { 
	    button2= (Button) findViewById(R.id.button2);
	    button2.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), JustLittle.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
	
	public void addListenerOnButton4() { 
	    button3= (Button) findViewById(R.id.button3);
	    button3.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), NiceMeeting.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
	
	public void addListenerOnButton5() { 
	    button4= (Button) findViewById(R.id.button4);
	    button4.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), YourName.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
	
	public void addListenerOnButton6() { 
	    button5= (Button) findViewById(R.id.button5);
	    button5.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), MyName.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
}
