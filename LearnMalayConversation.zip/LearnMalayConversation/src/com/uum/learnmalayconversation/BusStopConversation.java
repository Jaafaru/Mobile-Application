package com.uum.learnmalayconversation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class BusStopConversation extends Activity {
	Button button1, button2, button3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bus_stop_conversation);
		
		addListenerOnButton3();
	}

	public void addListenerOnButton3() { 
	    button3= (Button) findViewById(R.id.button3);
	   button3.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), StartLearning.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
}
