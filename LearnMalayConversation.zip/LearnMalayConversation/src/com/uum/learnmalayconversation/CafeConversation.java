package com.uum.learnmalayconversation;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class CafeConversation extends Activity {
	Button button7;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cafe_conversation);
		
		addListenerOnButton();
	}

	public void addListenerOnButton() { 
	    button7= (Button) findViewById(R.id.button7);
	   button7.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), StartLearning.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
}
