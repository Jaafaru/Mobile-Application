package com.uum.learnmalayconversation;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MyName extends Activity {
	Button btn1, btn2;
	MediaPlayer mp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_name);
		addListenerOnButton();
		addListenerOnButton2();
	}

	public void addListenerOnButton() { 
        btn1 = (Button) findViewById(R.id.button1);
        btn1.setOnClickListener(new OnClickListener() {
       	 
        

        	 public void onClick(View arg0) {
            		mp = MediaPlayer.create(MyName.this, R.raw.btnsnd);
            		
            		mp.start();
                    
                     


}
});
	   }
	public void addListenerOnButton2() { 
	    btn2= (Button) findViewById(R.id.button2);
	    btn2.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), Introduction.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
}
