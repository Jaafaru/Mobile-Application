package com.uum.learnmalayconversation;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class StartLearning extends Activity {
	Button button1, button2, button3, button4, button5, button6, button7;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start_learning);
		
		addListenerOnButton1();
		addListenerOnButton2();
		addListenerOnButton3();
		addListenerOnButton4();
		addListenerOnButton5();
		addListenerOnButton6();
		addListenerOnButton7();
	}

	 
    public void addListenerOnButton1() { 
	    button1= (Button) findViewById(R.id.button1);
	   button1.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), SimpleSentences.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
    
    public void addListenerOnButton2() { 
	    button2= (Button) findViewById(R.id.button2);
	   button2.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), GreetingSentences.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
    
    public void addListenerOnButton3() { 
	    button3= (Button) findViewById(R.id.button3);
	   button3.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), UniversityConversation.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
    
    public void addListenerOnButton4() { 
	    button4= (Button) findViewById(R.id.button4);
	   button4.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), BusStopConversation.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
    
    public void addListenerOnButton5() { 
	    button5= (Button) findViewById(R.id.button5);
	   button5.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), CafeConversation.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
    
    public void addListenerOnButton6() { 
	    button6= (Button) findViewById(R.id.button6);
	   button6.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), MallConversation.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
    
    public void addListenerOnButton7() { 
	    button7= (Button) findViewById(R.id.button7);
	   button7.setOnClickListener(new OnClickListener() {
	   	 
	    

	    	 public void onClick(View arg0) {

	             Intent intent = new Intent
	                     (getApplicationContext(), MainActivity.class);
	                 startActivity(intent); 

	    	 }

	   });
	}
}
