package com.uum.learnmalayconversation;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class UniversityConversation extends Activity {
	Button button1, button2, button3, button4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_university_conversation);
		
		addListenerOnButton4();
	}

	 public void addListenerOnButton4() { 
		    button4= (Button) findViewById(R.id.button4);
		   button4.setOnClickListener(new OnClickListener() {
		   	 
		    

		    	 public void onClick(View arg0) {

		             Intent intent = new Intent
		                     (getApplicationContext(), StartLearning.class);
		                 startActivity(intent); 

		    	 }

		   });
		}
}
