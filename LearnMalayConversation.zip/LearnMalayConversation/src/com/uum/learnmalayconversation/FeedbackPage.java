package com.uum.learnmalayconversation;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FeedbackPage extends Activity {
		Button button1, button2;
		EditText textTo;
		EditText textSubject;
		EditText textMessage;
		

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feedback_page);
		
		addListenerOnButton();
		addListenerOnButton1();
		
		textMessage = (EditText) findViewById(R.id.editTextMessage);
	}
		
		public void addListenerOnButton() { 
		    button2= (Button) findViewById(R.id.button2);
		   button2.setOnClickListener(new OnClickListener() {

		    	 public void onClick(View arg0) {

		             Intent intent = new Intent
		                     (getApplicationContext(), MainActivity.class);
		                 startActivity(intent); 
		               
		    	 }

		   });
		
	}

		public void addListenerOnButton1() { 
		    button1= (Button) findViewById(R.id.button1);
		   button1.setOnClickListener(new OnClickListener() {
	
		    	 public void onClick(View arg0) {
		    		 
		    		 String [] to = new String [] {"Tosinomotola@yahoo.com"};
		    		 String subject = ("Report Issues!!! -- ");
					  String message = textMessage.getText().toString();
		 
					  Intent email = new Intent(Intent.ACTION_SEND);
					  email.putExtra(Intent.EXTRA_EMAIL,  to);
					  email.putExtra(Intent.EXTRA_SUBJECT, subject);
					  email.putExtra(Intent.EXTRA_TEXT, message);

					  //need this to prompts email client only
					  email.setType("message/rfc822");
					  
					  startActivity(Intent.createChooser(email, "Choose an Email client :"));
		
		                 
	}

		   });
		}
	
}
