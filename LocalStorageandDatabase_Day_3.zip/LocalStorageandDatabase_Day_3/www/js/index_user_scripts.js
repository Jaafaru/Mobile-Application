/*jshint browser:true */

var customersArea = [];
     var updateId = -1;
     
     function loadManagePage() {
         $.ajax({
            url: "http://localhost/mobileapps/db_select.php",
            dataType: "json",
            success: function (result) {
             var tbl = '<table style="width:100%" id="managetbl" border="1"><tr><th>ID</th><th>Name</th><th>Delete</th><th>Update</th><tr></table>';
             $("#outmanage").html(tbl);
             
             customersArea = result.customers;
             for(var i = 0; i < result.customers.length; i++) {
                var customer = result.customers[i];
                var row = '<tr><td>' +customer.id + '</td><td>' + customer.name + '</td><td><button onclick="deleteCustomer(' + customer.id + ')">Delete</button></td><td><button onclick="updateCustomer(' + customer.id +')">Update</button></td></tr>';
             $("table").append(row);
             
         }
                $("th, td").css({
             "padding": "10px",
             "text-align": "left"
         });
         
         }, 
             error: function (jqXHR, status, thrown) {
                 alert("error weh ..." +thrown);
             }
             
         });
     }
    
     function updateCustomer(customerId) {
             
             for (var i = 0; i < customersArea.length; i++) {
                 var customer = customersArea[i];
                
                 //alert(customer.id);
                 if(customer.id == customerId) {
                     $("#updid").val(customerId);
                     $("#updic").val(customer.ic);
                     $("#updname").val(customer.name);
                     $("#upddob").val(customer.DOB);
                     $("#updaddress").val(customer.address);
                     
                     if (customer.gender == "Male"){
                         $('input:radio[name="gender"]').filter('[id="male"]').attr('checked', true);
                     } else {
                         alert(customer.gender);
                 $('input:radio[name="gender"]').filter('[id="female"]').attr('checked', true);
                     }
                     
                     updateId = customerId;
                     activate_page("#uib_page_update_customer");
                     break;
                 }
             }
         }

function displayCustomer(customerId) {
            
             $("#infodetail").html("");
                
    $.ajax({
            type: "POST",
            url: "http://localhost/mobileapps/db_search1.php",
            dataType: "json",
            data: "id=" + customerId,
            success: function (result) {
                
                for (var i = 0; i < result.customers.length; i++){
                    //alert(result.customers.length);
                    var customer = result.customers[i];
                    var tbl1 = '<h3>INFO DETAIL</h3><br><table border="1" style="width:100%;"><tr><td>ID</td><td>' + customer.id + '<tr><td>IC</td><td>' + customer.ic + '<tr><td>Name</td><td>' + customer.name + '<tr><td>Date of Birth</td><td>' + customer.DOB + '<tr><td>Date of Birth</td><td>' + customer.gender + '<tr><td>Address</td><td>' + customer.address + '</td></tr></table><br>';
                    $("#infodetail").html(tbl1);
                }
                $("td").css({
                    "padding": "10px"
                });
                $("tr td:first-child").css({
                    "font-weight": "bold",
                    "width": "30%"
                });      
         

            }, 
             error: function (jqXHR, status, thrown) {
                 alert("error weh ..." +thrown);
             }
             
         });
     }

function deleteCustomer(customerId) {
    
    if (confirm('Data is ready to be deleted?')) {
        
        var myURL = "http://localhost/mobileapps/db_delete.php";
        
        $.ajax({
            type: "POST",
            url: myURL,
            data: "id=" + customerId,
            success: function (msg) {
                alert(msg);
                loadManagePage();
            },
            error: function (xhr, textStatus, errorThrown) {
                alert("error ..." + xhr.statusText);
            }
        });
    } else {
        alert('That ok ... maybe next time');
    }
}


/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */

    function validateFld(x, fld) {
        if (x === null || x === "") {
            alert(fld + "must be filled out");
            return false;
        } else return true;
    }
    
 function register_event_handlers()
 {        
     /* button  LIST OF CUSTOMERS */
    
    
        /* button  LIST OF CUSTOMERS */
    $(document).on("click", ".uib_w_3", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_request"); 
        $.ajax({
            url:"http://localhost/mobileapps/db_select.php",
            dataType: "json",
            success: function (result) {
                var $output = $('#output4');
                $output.html("");
                for (var i = 0; i < result.customers.length; i++){
                    //alert(result.customers.length);
                    var customer = result.customers[i];
                    var tbl = '<table border="1" style="width:100%;"><tr><td>ID</td><td>' + customer.id + '<tr><td>IC</td><td>' + customer.ic + '<tr><td>Name</td><td>' + customer.name + '<tr><td>Date of Birth</td><td>' + customer.DOB + '<tr><td>Date of Birth</td><td>' + customer.gender + '<tr><td>Address</td><td>' + customer.address + '</td></tr></table><br>';
                    $output.append(tbl);
                }
                
                $("td").css({
                    "padding": "10px"
                });
                $("tr td:first-child").css({
                    "font-weight": "bold",
                    "width": "30%"
                });
            },
            error: function (jqXHR, status, thrown) {
                alert("error weh ..." + thrown);
            }
        });
        
         return false;
    });
    
        /* button  ADD CUSTOMER ALI */
    $(document).on("click", ".uib_w_8", function(evt)
    {
        /* your code goes here */ 
        var myURL = "http://localhost/mobileapps/db_insert1.php";
        $.ajax({
            type: "POST",
            url: myURL,
            success: function (msg) {
                alert(msg);
            },
            error: function (xhr, textStatus, errorThrown) {
                alert("error ..." + xhr.statusText);
            }
        });
         return false;
    });
    
        /* button  UPDATE CUSTOMER ALI */
    $(document).on("click", ".uib_w_5", function(evt)
    {
        /* your code goes here */ 
        var myURL = "http://localhost/mobileapps/db_update1.php";
        $.ajax({
            type: "POST",
            url: myURL,
            success: function (msg) {
                alert(msg);
            },
            error: function (xhr, textStatus, errorThrown) {
                alert("error ..." + xhr.statusText);
            }
        });
         return false;
    });
    
        /* button  DELETE CUSTOMER ALI */
    $(document).on("click", ".uib_w_6", function(evt)
    {
        /* your code goes here */ 
        var myURL = "http://localhost/mobileapps/db_delete1.php";
        $.ajax({
            type: "POST",
            url: myURL,
            success: function (msg) {
                alert(msg);
            },
            error: function (xhr, textStatus, errorThrown) {
                alert("error ..." + xhr.statusText);
            }
        });
         return false;
    });
    
        /* button  ADD NEW CUSTOMER */
    $(document).on("click", ".uib_w_4", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_insert");
        
         return false;
    });
    
        /* button  .uib_w_17 */
    $(document).on("click", ".uib_w_17", function(evt)
    {
        /* your code goes here */ 
        var id0 = $('#id1').val();
        var ic0 = $('#ic1').val();
        var name0 = $('#name1').val();
         var dob0 = $('#dob1').val();
        var address0 = $('#address1').val();
        var gender0 =$("input:radio[name ='gender']:checked").val();
        
        var isValid = true;
        //isValid = validateIC(ic0);
        //isValid = validateFld(id0, "ID");
        
        if (isNaN(ic0) || !validateFld(ic0, "IC")){
            isValid =false;
        }else {
            isValid = validateFld(name0, "Name");
            if (isValid) {
                isValid = true;
            } else {
                isValid = false;
            }
        }
        
        if (isValid) {
            // Get value from form
             alert("Data: " + id0 + " " + ic0 + " " + name0 + " " + dob0 + " " + gender0 + " " + address0);
            
            //Send data to server
            alert("Dah ready nak insert ...");
            var formData = $("#id1, #ic1, #name1, #dob1, #gender, #address1").serialize();
            var myURl = "http://localhost/mobileapps/db_insert.php";
            alert("form: " +myURl);
            
            $.ajax({
                type: "POST",
                url: myURl,
                data: formData,
                success: function (msg) {
                    alert(msg);
                },
                error: function (xhr, textStatus, errorThrown){
                    alert("error ..." + xhr.statusText);
                }
            });
        } else {
            alert("Error occur during input... please retry");
        }
         return false;
    });    
    
        /* button  SEARCH */
    $(document).on("click", ".uib_w_25", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_search1"); 
        
         return false;
    });
    
        /* button  REPORT */
    $(document).on("click", ".uib_w_11", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
    
        /* button  Display */
    $(document).on("click", ".uib_w_29", function(evt)
    {
        /* your code goes here */ 
        var idcus = $('#search1').val();
        
        $.ajax({
            type: "POST",
            dataType: "json",
             url:"http://localhost/mobileapps/db_search1.php",
            // this id is from my database table
            data: "id=" +idcus,
            success: function (result) {
                var $output = $('#output5');
                $output.html("");
                
                for (var i = 0; i < result.customers.length; i++){
                    //alert(result.customers.length);
                    var customer = result.customers[i];
                    var tbl = '<table border="1" style="width:100%;"><tr><td>ID</td><td>' + customer.id + '<tr><td>IC</td><td>' + customer.ic + '<tr><td>Name</td><td>' + customer.name + '<tr><td>Date of Birth</td><td>' + customer.DOB + '<tr><td>Date of Birth</td><td>' + customer.gender + '<tr><td>Address</td><td>' + customer.address + '</td></tr></table><br>';
                    $output.append(tbl);
                }
                $("td").css({
                    "padding": "10px"
                });
                $("tr td:first-child").css({
                    "font-weight": "bold",
                    "width": "30%"
                });
            },
            error: function (jqXHR, status, thrown) {
                alert("error weh ..." + thrown);
            }
        });
         return false;
    });
    
        /* button  MANAGE CUSTOMER */
    $(document).on("click", ".uib_w_7", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_manage");
        loadManagePage();
         return false;
    });
    
        /* button  .uib_w_32 */
    $(document).on("click", ".uib_w_32", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  .uib_w_33 */
    $(document).on("click", ".uib_w_33", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  .uib_w_34 */
    $(document).on("click", ".uib_w_34", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  .uib_w_35 */
    $(document).on("click", ".uib_w_35", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  .uib_w_47 */
    $(document).on("click", ".uib_w_47", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_manage"); 
         return false;
    });
    
        /* button  UPDATE THE CUSTOMER */
    $(document).on("click", ".uib_w_46", function(evt)
    {
        /* your code goes here */ 
        alert("Ready for updating ...");
        validateFld($("#updic").val(), "ic");
        validateFld($("#updname").val(), "name");
        
        var formData = $("#updic, #updname, .gender, #upddob, #updaddress").serialize() + "&id=" + updateId;
        
        alert(updateId);
        $.ajax({
            type: "POST",
            url: "http://localhost/mobileapps/db_update.php",
            data: formData,
            success: function (msg) {
                alert(msg);
                loadManagePage();
                activate_page("#uib_page_manage");
        },
               error: function (xhr, textStatus, errorThrown) {
            alert("error ..." + xhr.statusText);
        }
        });
         return false;
    });
    
        /* button  SEARCH */
    $(document).on("click", ".uib_w_51", function(evt)
    {
        /* your code goes here */ 
        
         var namecus = $('#cusname').val();
        
        $.ajax({
            type: "POST",
            dataType: "json",
             url:"http://localhost/mobileapps/db_searchname.php",
            // this id is from my database table
            data: "name=" +namecus,
            success: function (result) {
                var tbl = '<table style="width:100%" id="managetbl" border="1"><tr><th>ID</th><th>Name</th><th>Detail Information</th><tr></table>';
             $("#resultname").html(tbl);
             
             customersArea = result.customers;
             for(var i = 0; i < result.customers.length; i++) {
                var customer = result.customers[i];
                var row = '<tr><td>' +customer.id + '</td><td>' + customer.name + '</td><td><button onclick="displayCustomer(' + customer.id +')">Display</button></td></tr>';
             $("table").append(row);
             
         }
                $("th, td").css({
             "padding": "10px",
             "text-align": "left"
         });
                
            },
            error: function (jqXHR, status, thrown) {
                alert("error weh ..." + thrown);
            }
        });
         return false;
    });
    
        /* button  SEARCH BY NAME */
    $(document).on("click", ".uib_w_48", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_search2"); 
         return false;
    });
    
        /* button  .uib_w_54 */
    $(document).on("click", ".uib_w_54", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
