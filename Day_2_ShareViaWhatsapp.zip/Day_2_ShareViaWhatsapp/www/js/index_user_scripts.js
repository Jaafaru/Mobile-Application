/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Button */
    $(document).on("click", ".uib_w_3", function(evt)
    {
        /* your code goes here */ 
         GMaps.geolocate({
            success: function (position) {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                var alt = position.coords.altitude;
                var acc = position.coords.accuracy;
                
                $("#display").modal("toggle");
                 $("#outarea").html("Latitude: " + lat + " " + "Longitude: " + lng + " " + "Altitude: " + alt + " " + "Accuracy: " + acc );
                
             //alert("Your lat-lng (" + lat + "," + lng + "," + alt + "," + acc + ")");
        
        var map = new GMaps ({
            div: '#map',
            lat: lat,
            lng: lng
            
        });
                
         GMaps.createPanorama ({
                    el: '#imej',
                    lat: lat,
                    lng: lng
                    });
                
                 map.addMarker({
                    lat: lat,
                    lng: lng,
                    alt: alt,
                    infoWindow: {
                        content: '<b> <i> You are here! </i></b>'
                    }
                });
    
                
                if (acc <= 150) {
                
                    alert("You can share your location now");
                    
                var strURL = "My Lat-Lng is (" + lat + "," + lng + "," + alt + ")";
                var msg = encodeURIComponent(strURL);
                var whatsapp_url = "whatsapp://send?text=" + msg;
                var strHREF = "<a class='btn btn-info' role='button' href='" + whatsapp_url + "'>Click here to share your location</a>";
                //alert(strHREF);
                $("#output").html(strHREF);
                }else
                    alert("Please wait for 2-4 seconds");
            
                
            },
            error: function (error) {
                alert("Error in Your Geolocation. Try again.");
            }
             
         });
         return false;
    });
    
        /* button  Show Markers */
    $(document).on("click", ".uib_w_10", function(evt)
    {
        /* your code goes here */ 
         var map = new GMaps ({
            div: '#map',
            lat: 6.46815,
            lng: 100.50706
            
        });
        map.setZoom(9);
        
         map.addMarker({
                    lat: 6.46815,
                    lng: 100.50706,
                    infoWindow: {
                        content: '<b> <i> UUM is here! </i></b>'
                    }
                });
        
        map.addMarker({
                    lat: 6.2644,
                    lng: 100.4202,
                    infoWindow: {
                        content: '<b> <i> Jitra is here! </i></b>'
                    }
                });
        
        var thePath = [[6.46815, 100.50706], [6.2644, 100.4202]];
        
        map.drawPolyline({
            path: thePath,
            strokeColor: '#131540',
            strokeOpacity: 0.6,
            strokeWeight: 6
        });
        
        map.drawRoute({
           origin: [6.46815, 100.50706],
            destination: [6.2644, 100.4202],
            travelMode: 'driving',
            strokeColor: '#FF0000',
            strokeOpacity: 0.6,
            strokeWeight: 6
        });
        
        
        
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
