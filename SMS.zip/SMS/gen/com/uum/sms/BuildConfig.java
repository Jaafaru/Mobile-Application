/** Automatically generated file. DO NOT MODIFY */
package com.uum.sms;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}