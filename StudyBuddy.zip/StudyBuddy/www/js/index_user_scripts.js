/*jshint browser:true */
var projectArea = [];
var updateId = -1;

function loadproject(){
    $.ajax({
            url: "http://localhost/sb/project.php",
            dataType: "json",
            success: function (result) {
             var tbl = '<table style="width:100%" id="managetbl" border="1"><tr><th>Project Title</th><tr></table>';
             $("#projectlist").html(tbl);
             
             projectArea = result.projects;
             for(var i = 0; i < result.projects.length; i++) {
                var project = result.projects[i];
                var row = '<tr><td>' + project.title + '</td><td><button onclick="updateProject(' + project.id + ')">Update</button></td><td><button onclick="deleteproject(' + project.id + ')">Delete</button></td></tr>';
             $("table").append(row);
             
         }
                $("th, td").css({
             "padding": "10px",
             "text-align": "left"
         });
         
         }, 
             error: function (jqXHR, status, thrown) {
                 alert("error weh ..." +thrown);
             }
             
         });
}



function loadprojectstudent(){
    $.ajax({
            url: "http://localhost/sb/project.php",
            dataType: "json",
            success: function (result) {
             var tbl = '<table style="width:100%" id="managetbl" border="1"><tr><th> Title</th><th> Description</th><tr></table>';
             $("#projectliststud").html(tbl);
             
             projectArea = result.projects;
             for(var i = 0; i < result.projects.length; i++) {
                var project = result.projects[i];
                var row = '<tr><td>' + project.title + '</td><td>' + project.description + '</td></tr>';
             $("table").append(row);
             
         }
                $("th, td").css({
             "padding": "10px",
             "text-align": "left"
         });
         
         }, 
             error: function (jqXHR, status, thrown) {
                 alert("error weh ..." +thrown);
             }
             
         });
}

function loadnews(){
    
    $.ajax({
            url: "http://localhost/sb/newslist.php",
            dataType: "json",
            success: function (result) {
             var tbl = '<table style="width:100%" id="managetbl" border="1"><tr><th>Announcement</th><tr></table>';
             $("#newslist").html(tbl);
             
             projectArea = result.news1;
             for(var i = 0; i < result.news1.length; i++) {
                var news = result.news1[i];
                var row = '<tr><td>' + news.news + '</td><td><button onclick="deletenews(' + news.id + ')">Delete</button></td></tr>';
             $("table").append(row);
             
         }
                $("th, td").css({
             "padding": "10px",
             "text-align": "left"
         });
         
         }, 
             error: function (jqXHR, status, thrown) {
                 alert("error weh ..." +thrown);
             }
             
         });
}
function loadnewsStud(){
    
    $.ajax({
            url: "http://localhost/sb/newslist.php",
            dataType: "json",
            success: function (result) {
             var tbl = '<table style="width:100%" id="managetbl" border="1"><tr><th>Announcement</th><tr></table>';
             $("#newsliststud").html(tbl);
             
             projectArea = result.news1;
             for(var i = 0; i < result.news1.length; i++) {
                var news = result.news1[i];
                var row = '<tr><td>' + news.news + '</td></tr>';
             $("table").append(row);
             
         }
                $("th, td").css({
             "padding": "10px",
             "text-align": "left"
         });
         
         }, 
             error: function (jqXHR, status, thrown) {
                 alert("error weh ..." +thrown);
             }
             
         });
}

function updateProject(projectId) {
             
             for (var i = 0; i < projectArea.length; i++) {
                 var project = projectArea[i];
                
                 //alert(customer.id);
                 if(project.id == projectId) {
                     //$("#updid").val(customerId);
                     $("#updtitle").val(project.title);
                     $("#upddescrip").val(project.description);
                     
                     updateId = projectId;
                     activate_page("#update_project");
                     break;
                 }
             }
         }

function deleteproject(projectId) {
    
    if (confirm('Data is ready to be deleted?')) {
        
        var myURL = "http://localhost/sb/project_delete.php";
        
        $.ajax({
            type: "POST",
            url: myURL,
            data: "id=" + projectId,
            success: function (msg) {
                alert(msg);
                loadproject();
            },
            error: function (xhr, textStatus, errorThrown) {
                alert("error ..." + xhr.statusText);
            }
        });
    } else {
        alert('That ok ... maybe next time');
    }
}

function deletenews(newsId) {
    
    if (confirm('Data is ready to be deleted?')) {
        
        var myURL = "http://localhost/sb/news_delete.php";
        
        $.ajax({
            type: "POST",
            url: myURL,
            data: "id=" + newsId,
            success: function (msg) {
                alert(msg);
                loadnews();
            },
            error: function (xhr, textStatus, errorThrown) {
                alert("error ..." + xhr.statusText);
            }
        });
    } else {
        alert('That ok ... maybe next time');
    }
}


/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
    
    function validateEmail(email1) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email1);
        }
    
    
 function register_event_handlers()
 {
    
    
     /* button  #back_from_sign_up */
    $(document).on("click", "#back_from_sign_up", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #homepage_sign_up_button */
    $(document).on("click", "#homepage_sign_up_button", function(evt)
    {
         /*global activate_page */
         activate_page("#sign_up_01"); 
         return false;
    });
    
        /* button  #student_back_button */
    $(document).on("click", "#student_back_button", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #homepage_login */
    
    
        /* button  #back_button_project_student */
    $(document).on("click", "#back_button_project_student", function(evt)
    {
         /*global activate_page */
         activate_page("#student_00"); 
         return false;
    });
    
        /* button  #student_announcement_button */
    $(document).on("click", "#student_announcement_button", function(evt)
    {
         /*global activate_page */
         activate_page("#student_announcement"); 
        loadnewsStud();
         return false;
    });
    
        /* button  #back_button_announcement_student */
    $(document).on("click", "#back_button_announcement_student", function(evt)
    {
         /*global activate_page */
         activate_page("#student_00"); 
         return false;
    });
    
        /* button  #back_button_student_message */
    $(document).on("click", "#back_button_student_message", function(evt)
    {
         /*global activate_page */
         activate_page("#student_00"); 
         return false;
    });
    
        /* button  #student_message_button */
    $(document).on("click", "#student_message_button", function(evt)
    {
         /*global activate_page */
         activate_page("#student_message"); 
         return false;
    });
    
        /* button  #back_button_student_help */
    $(document).on("click", "#back_button_student_help", function(evt)
    {
         /*global activate_page */
         activate_page("#student_00"); 
         return false;
    });
    
        /* button  #student_button_help */
    $(document).on("click", "#student_button_help", function(evt)
    {
         /*global activate_page */
         activate_page("#student_help"); 
         return false;
    });
    
        /* button  #back_button_student_project */
    $(document).on("click", "#back_button_student_project", function(evt)
    {
         /*global activate_page */
         activate_page("#student_00"); 
         return false;
    });
    
        /* button  #student_project_button */
    $(document).on("click", "#student_project_button", function(evt)
    {
         /*global activate_page */
         activate_page("#student_project");
        loadprojectstudent();
         return false;
    });
    
        /* button  #sign_up_button_02 */
    $(document).on("click", "#sign_up_button_02", function(evt)
    {
        /* your code goes here */ 
        
        var message = "";
            if ($('#name1').val() === "") {
                message = "name";
            }  else if ($('#email_01_1').val() === "") {
                message = "email";
            } else if (!validateEmail($('#email_01_1').val())) {
                message = "valid email";
            } else if ($('#password_01_1').val() === "") {
                message = "password";
            } else if ($("#password_02_1").val() != $('#password_01_1').val()) {
                message = " right confirm password";
            } else if ($('#status1').val() === "") {
               message = "status";
            }
        
        if (message === "") {
            
            //alert("Data is ready to be inserted ...");
            var formData = $("#name1, #email_01_1, #password_01_1, #status1").serialize();
           var myURL = "http://localhost/sb/register.php";
            
            $.ajax({
                type: "POST",
                url: myURL,
                data: formData,

            success: function (msg) {
                alert(msg);
                     $('#name1').val("");
                     $('#email_01_1').val("");
                     $('#password_01_1').val("");
                     $('#password_02_1').val("");
                     $('#status1').val("");
                 activate_page("#mainpage");

            },
           error: function(xhr, textStatus, errorThrown){
                alert("error ..." + xhr.statusText);
                  }
    });
               

            } else {
                alert("Please input " + message);
            }
        
         return false;
    });
    
        /* button  #homepage_login */
    $(document).on("click", "#homepage_login", function(evt)
    {
        /* your code goes here */   
        
        var login = $("#status1l").val();
        var formData = $("#username1, #pass1").serialize();
        
         
        if (login == "student") {
                        $.ajax({
                            type: "POST",
                            url: "http://localhost/sb/login.php",
                            data: formData,
                            success: function (msg) {
                    if (msg == "1") {
        activate_page("#student_00"); 
                    } else {
                    alert("The username or password you entered is incorrect. st");
                    }

                }
            });
             }else if (login == "lecturer") {
                        $.ajax({
                            type: "POST",
                            url: "http://localhost/sb/lecturerlogin.php",
                            data: formData,
                            success: function (msg) {
                    if (msg == "1") {
        activate_page("#lecturer_00"); 
                    } else {
                    alert("The username or password you entered is incorrect.lol");
                    }

                }
            });
             }
        
         return false;
    });
    
        /* button  Manage Projects */
    $(document).on("click", ".uib_w_46", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_project"); 
         return false;
    });
    
        /* button  Add Project */
    $(document).on("click", ".uib_w_50", function(evt)
    {
        /* your code goes here */ 
        //var pi0 = $('#pi1').val();
        var message = "";
            if ($('#title').val() === "") {
                message = "title";
            }  else if ($('#description').val() === "") {
                message = "description";
            }
        
        if (message === "") {
         //alert("Data is ready to be inserted ...");
            var formData = $("#title,#description").serialize();
        var myURL = "http://localhost/sb/addproject.php";
            
            $.ajax({
                type: "POST",
                url: myURL,
                data: formData, 
                success: function (msg) {
                    alert(msg);
                     $('#title').val("");
                    $('#description').val("");
                    
                },
                error: function(xhr, textStatus, errorThrown){
                alert("error ..." + xhr.statusText);
            }
            });
            } else {
                alert("Please input " + message);
            }
         return false;
    });
    
        /* button  Veiw Project */
    $(document).on("click", ".uib_w_53", function(evt)
    {
        /* your code goes here */ 
        
        activate_page("#lecturer_projectlist"); 
        loadproject();
        
         return false;
    });
    
        /* button  #back_button_lecturer_project */
    $(document).on("click", "#back_button_lecturer_project", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_00"); 
         return false;
    });
    
        /* button  #back_button_manage_project */
    $(document).on("click", "#back_button_manage_project", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_project"); 
         return false;
    });
    
        /* button  #lecturer_back_button */
    $(document).on("click", "#lecturer_back_button", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #back_button_manage_news */
    $(document).on("click", "#back_button_manage_news", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_news"); 
         return false;
    });
    
        /* button  #back_button_news_lecturer */
    $(document).on("click", "#back_button_news_lecturer", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_00"); 
         return false;
    });
    
        /* button  Veiw Annoucement */
    $(document).on("click", ".uib_w_62", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_newslist");
        loadnews();
         
         return false;
    });
    
        /* button  Manage Announcement */
    $(document).on("click", ".uib_w_48", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_news"); 
        
         return false;
    });
    
        /* button  Add Announcement */
    $(document).on("click", ".uib_w_61", function(evt)
    {
        /* your code goes here */ 
        
        var message = "";
            if ($('#news1').val() === "") {
                message = "Announcement";
            }  
        
        if (message === "") {
         alert("Data is ready to be inserted ...");
            var formData = $("#news1").serialize();
        var myURL = "http://localhost/sb/addnews.php";
            
            $.ajax({
                type: "POST",
                url: myURL,
                data: formData, 
                success: function (msg) {
                    alert(msg);
                     $('#news1').val("");
                    
                    
                },
                error: function(xhr, textStatus, errorThrown){
                alert("error ..." + xhr.statusText);
            }
            });
            } else {
                alert("Please input " + message);
            }
         return false;
    });
    
        /* button  Update Project */
    $(document).on("click", ".uib_w_70", function(evt)
    {
        /* your code goes here */ 
        alert("Ready for updating ...");
        
        
        var formData = $("#updtitle, #upddescrip").serialize() + "&id=" + updateId;
        
        //alert(updateId);
        $.ajax({
            type: "POST",
            url: "http://localhost/sb/project_update.php",
            data: formData,
            success: function (msg) {
                alert(msg);
                
                activate_page("#lecturer_projectlist");
                loadproject();
        },
               error: function (xhr, textStatus, errorThrown) {
            alert("error ..." + xhr.statusText);
        }
        });
         return false;
    });
    
        /* button  #update_back_projectlist */
    $(document).on("click", "#update_back_projectlist", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_projectlist"); 
         return false;
    });
    
        /* button  Send Message */
    $(document).on("click", ".uib_w_47", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_message"); 
         return false;
    });
    
        /* button  #back_button_msg */
    $(document).on("click", "#back_button_msg", function(evt)
    {
         /*global activate_page */
         activate_page("#lecturer_00"); 
         return false;
    });
    
        /* button  Send */
    $(document).on("click", ".uib_w_78", function(evt)
    {
        /* your code goes here */ 
        var message = "";
            if ($('#to').val() === "") {
                message = "Student email";
            }  else if ($('#from').val() === "") {
                message = "Lecturer email";
            } else if ($('#msg').val() === "") {
                message = "Message";
            }
        
        if (message === "") {
         //alert("Data is ready to be inserted ...");
            var formData = $("#to,#from,#msg").serialize();
        var myURL = "http://localhost/sb/addmessage.php";
            
            $.ajax({
                type: "POST",
                url: myURL,
                data: formData, 
                success: function (msg) {
                    alert(msg);
                     $('#to').val("");
                    $('#from').val("");
                     $('#msg').val("");
                    
                },
                error: function(xhr, textStatus, errorThrown){
                alert("error ..." + xhr.statusText);
            }
            });
            } else {
                alert("Please input " + message);
            }
         return false;
    });
    
        /* button  Retrieve Mails */
    $(document).on("click", ".uib_w_81", function(evt)
    {
        /* your code goes here */ 
        var mail1 = $('#mail').val();
        
        $.ajax({
            type: "POST",
            dataType: "json",
             url:"http://localhost/sb/message.php",
            // this id is from my database table
            data: "mail=" +mail1,
            success: function (result) {
                
                var tbl = '<h3>INBOX</h3><br><table border="1" style="width:100%;"></table>';
             $("#mymails").html(tbl);
             
             projectArea = result.messages;
             for (var i = 0; i < result.messages.length; i++){
                    //alert(result.customers.length);
                    var message = result.messages[i];
                var row = '<tr><td>From</td><td>' + message.mailFrom + '<tr><td>Message</td><td>' + message.message + '</td></tr>';
             $("table").append(row);
                
                
                }
                $("td").css({
                    "padding": "10px"
                });
                $("tr td:first-child").css({
                    "font-weight": "bold",
                    "width": "30%"
                });      
    
                
            },
            error: function (jqXHR, status, thrown) {
                alert("error weh ..." + thrown);
            }
        });
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
