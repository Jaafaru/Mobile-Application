package com.uum.arraylocation;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity {
    static final LatLng KENTUCKY = new LatLng(37.833333, -85.833333);

    private GoogleMap map;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(KENTUCKY, 15));

        // Zoom in, animating the camera.
        map.animateCamera(CameraUpdateFactory.zoomTo(7), 2000, null);

        // Enable the My Location Layer
        map.setMyLocationEnabled(true);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });





        Double[] Lat = {
                37.7867266, 37.0703517, 37.1610806, 37.318367, 37.3559204, 37.4154066, 37.4757622, 37.7450252, 37.6318978, 37.0716803, 36.7333486,
                36.8637044, 36.9181305, 36.8736459, 36.93253, 37.0436832, 37.1516087, 36.712052, 36.8082663, 37.1799935, 37.8928444, 37.7488563, 37.5882222,
                37.4991846, 37.5392879, 37.3721288, 37.1922315, 37.102841, 36.9813651, 36.660251, 37.1301316, 37.1734765, 37.0505279, 36.9179492, 37.2742692,
                37.2116415, 37.2412938, 37.2696374, 37.5464147, 37.5693561, 37.7146149, 37.7647463, 37.635366, 37.6417237, 37.8515069, 37.6000712, 37.6655401,
                37.7101039, 37.8721419, 37.9711379, 38.0069215, 38.135998, 38.105713, 38.160352, 38.223825, 38.188871, 38.235703, 38.3586935, 38.3069755,
                38.6109009, 38.4004693, 38.5997367, 38.6414842, 38.5741722, 38.1756649, 38.2686626, 38.4329612, 38.673506, 38.1916673, 38.2265882, 38.7363261,
                38.9734399, 38.977975, 38.903505, 38.7418795, 38.5102869, 38.4260502, 38.2687025, 38.2097987, 38.2074495, 38.1245065, 38.036634, 37.9976315,
                37.7785109, 37.9442351, 37.9631701, 37.9572905, 38.0575357, 37.6256607, 37.125056, 37.911885, 38.4948355, 38.5124872, 38.359333, 37.5453841,
                37.5846472, 37.8013131, 36.8453199, 37.6253998, 36.7839221, 37.3817563, 38.0765348, 37.3880817
        };



        Double[] Lon = {
                -87.608209, -88.1237899, -87.9148629, -87.5074402, -87.5448032, -87.8003148, -87.9515986, -87.9061638, -87.1148574, -87.3008418,
                -87.5661605, -87.290597, -86.8270899, -86.6544847, -86.490067, -86.4558939, -86.2038694, -86.3287002, -85.9428197, -85.8312895, -86.2219159,
                -85.8042332, -85.6896553, -85.6185338, -85.3974197, -85.3594512, -85.5906947, -85.3063504, -85.060269, -85.212777, -84.8720139, -84.8137247,
                -84.5698918, -84.1312625, -84.4614493, -84.4802606, -84.4223536, -84.6410206, -84.4564877, -84.2884479, -84.4089207, -84.3655048, -84.5597937,
                -84.7606165, -84.8732843, -85.0401771, -85.248661, -85.259706, -85.3155742, -85.689489, -85.8210816, -85.503977, -85.654787, -85.855705,
                -85.592095, -85.520966, -85.156767, -85.1048516, -85.1471807, -85.1186233, -85.3788328, -85.3060421, -85.3237933, -85.2994716, -84.8965549,
                -84.6066196, -84.8581488, -84.8477954, -84.541101, -84.5685446, -84.6280011, -84.721179, -84.749313, -84.441984, -84.0662604, -83.8971076,
                -83.8566679, -84.2433673, -84.2529869, -84.4785665, -84.3541421, -84.551631, -84.7000274, -84.5389521, -84.2261198, -84.2162117, -83.793939,
                -83.9017386, -83.5944371, -82.787241, -82.748201, -82.8310584, -82.7304443, -83.5611122, -84.3922468, -87.2933751, -87.0286427, -86.887219,
                -85.8036974, -85.0544964, -85.0726285, -84.9178708, -86.1989805
        };

        String[] Market = {
                "Cates Farm", "Broadbent B & B Foods", "Cayce's Pumpkin Patch", "Metcalfe Landscaping", "Brumfield Farm Market", "Dogwood Valley Farm",
                "Country Fresh Meats & Farmers Market", "Jim David Meats", "Trunnell's Farm Market", "Lovell's Orchard & Farm Market", "Zook's Produce", "The Country Barn",
                "Poore's Nursery & Farms", "Just Piddlin Farm", "Chaney's Dairy Barn & Restaurant", "Jackson's Orchard & Nursery, Inc.", "Mammoth Cave Transplants",
                "Habegger's Amish Market", "Kenny's Farmhouse Cheese", "Dennison's Roadside Market", "Roberts Family Farm", "Wooden Farm", "Lee's Garden Center, Florist & Gift Shop",
                "Hinton's Orchard & Farm Market", "Serenity Farm Alpacas", "Burton's Nursery & Garden Center", "Davis Family Farms", "Heavenly Haven Farm", "French Valley Farms",
                "Cravens Greenhouse", "Haney's Appledale Farm", "Hettmansperger's Greenhouse", "D & F Farms", "Double Hart Farm", "Owens Garden Center", "Hail's Farm",
                "Sinking Valley Vineyard & Winery, Inc.", "Todd's Greenhouse & Florist, LLC", "McQuerry's Family Farm-Herbs-N-Heirlooms", "Berea College Farm & Gardens",
                "Acres of Land Winery & Restaurant", "Baldwin Farms", "Wonder of Life Farm", "Chateau du Vieux Corbeau Winery/Old Crow Farm Winery", "Devine's Farm & Corn Maze",
                "Williams Country Market", "Serano Alpacas & Yarns", "St. Catharine Farm", "Capture Your Heart Alpacas", "Ridgeview Greenhouse & Nursery",
                "Country Corner Greenhouse & Nursery, Inc", "Sunny Acres Farm", "Morrison's Greenhouses", "George Gagel Farm Market, LLC", "Thieneman's Herbs & Perennials",
                "Tower View Farm & Nursery", "Gallrein Farms", "Sweet Home Spun in the Low Dutch Meetinghouse", "Mulberry Orchard, LLC", "Gregory Farms", "Sherwood Acres Beef",
                "Bray Orchard & Roadside Market", "Callis Orchards", "Bray Fruit", "Wilson's Nursery", "Triple J Farm", "Ayres Family Orchard", "Michels Family Farm", "Amerson Farm",
                "Bi-Water Farm & Greenhouse", "Alpine Hills Dairy Tour/Country Pumpkins", "Blue Ribbon Market", "Eagle Bend Alpacas Fiber & Gift Shoppe", "Redman's Farm",
                "The Greenhouse in Gertrude", "Croppers Greenhouse & Nursery", "McLean's Aerofresh Fruit", "Julie's Pumpkins", "Reed Valley Orchard", "Evans Orchard & Cider Mill",
                "Antioch Daylily Garden", "Golden Apple Fruit Market", "Boyd Orchards", "Serenity Hill Fiber & Living History Farm", "Beech Springs Farm Market",
                "Yuletide Tree Farm & Nursery", "Townsend's Sorghum Mill and Farm Market", "Bramble Ridge Orchard", "Country Garden Greenhouse", "Golden Apple Fruit Market",
                "Black Barn Produce, LLC", "Imel's Greenhouse", "Feathered Wing Farm Market", "Hutton-Loyd Tree Farm", "Halcomb's Knob, LLC", "Happy Hollow Farms", "Reid's Orchard",
                "McKinney Farm", "Crawford Farms", "Brian T. Guffey Livestock & Produce", "MeadowBrook Orchards & Farm", "Rising Sons Home Farm Winery", "VanMeter Family Farm"
        };

        String[] Address = {
                "Hwy 425 Henderson, KY 42420", "257 Mary Blue Road Kuttawa, KY 42055", "153 Farmersville Road Princeton, KY 42445",
                "410 Princeton Road Madisonville, KY 42431", "3320 Nebo Road Madisonville, KY 42431", "4551 State Route 109N Clay, KY 42404", "9355 US Hwy 60 W Sturgis, KY 42459",
                "350 T. Frank Wathen Rd. Uniontown, KY 42461", "9255 Hwy 431 Utica, KY 42376", "22850 Coal Creek Road Hopkinsville, KY 42240",
                "Intersection of KY107 & KY117 Herndon, KY  42240", "112 Britmart Road Elkton, KY 42220", "5486 Morgantown Road Russellville, KY 42276",
                "10830 S. Morgantown Rd.    Woodburn, KY 42170", "9191 Nashville Road, Bowling Green, KY 42101",
                "1280 Slim Island Road  Bowling Green, KY 42101", "5394 Brownsville Road Brownsville, KY 42210", "945 Perrytown Road    Scottsville, KY 42164",
                "2033 Thomerson Park Road Austin, KY 42123", "5824 S. Jackson Hwy. Horse Cave, KY 42749", "125 Kennedy Road Guston, KY  40142",
                "1869 Wooden Lane Elizabethtown, KY 42701", "1918 Bardstown Road Hodgenville, KY 42748", "8631 Campbellsville Road Hodgenville, KY 42748",
                "1380 Frogg Lane Raywick, KY 40060", "2212 Saloma Road Campbellsville, KY 42718", "313 Hwy 1464 Greensburg, KY 42743", "230 Heavenly Lane Columbia, KY 42728",
                "1842 N. Main St. Jamestown, KY 42629", "500 Cedar Hill Road Albany, KY 42602", "8350 West 80 Nancy, KY 42544-8756", "3917 N. Hwy 837 Science Hill, KY 42553",
                "755 Elihu Rush Branch Road Somerset, KY 42501", "6550 Cumberland Falls Road Corbin, KY 40701", "735 Latham Road Somerset, KY 42503",
                "Hwy 461, at 3 mile marker Somerset, KY 42503", "1300 Plato-Vanhook Road Somerset, KY 42503", "35 Skyline Drive Eubank, KY 42567",
                "169 Pine Hill Road Paint Lick, KY 40461", "230 N. Main St. Berea, KY 40404", "2285 Barnes Mill Road Richmond, KY 40475", "1113 Tates Creek Road Richmond, KY 40475",
                "686 Buckeye Road Lancaster, KY 40444", "471 Stanford Avenue Danville, KY 40422-1927", "623 Talmage-Mayo Road Harrodsburg, KY 40330",
                "4189 Craintown Rd. Gravel Switch, KY 40328", "1805 Booker Road Springfield, KY 40069", "2645 Bardstown Road Springfield, KY 40061",
                "9430 Bloomfield Road Bloomfield, KY 40008", "460 Buffalo Run Road Shepherdsville, KY 40165", "4877 Hwy 44E Shepherdsville, KY 40165",
                "6516 Echo Trail Jeffersontown, KY 40299", "5613 Cooper Chapel Road Louisville, KY 40229", "2400 Lower Hunters Trace Louisville, KY 40216",
                "9120 Blowing Tree Road Louisville, KY 40220", "12523 Taylorsville Road Jeffersontown, KY 40299", "1029 Vigo Road Shelbyville, KY 40065",
                "6805 Castle Hwy. Pleasureville, KY 40057", "1330 Mulberry Pike Shelbyville, KY 40065", "985 Vance Road Turners Station, KY 40075", "215 Parker Drive LaGrange, KY 40031",
                "2580 Hwy 42 W. Bedford, KY 40006", "3721 Hwy 421 N Bedford, KY 40006", "1660 Highway 421 N Bedford, KY 40006", "3690 East-West Connector (Rte 676) Frankfort, KY 40601",
                "2287 Long Lick Road Georgetown, KY 40324", "525 Wilson Lane Owenton, KY 40359", "4275 Hwy 1316 Sparta, KY 41086", "130 McClelland Circle Georgetown, KY 40324",
                "877 Cincinnati Road Georgetown, KY 40324", "2165 Sherman Mount Zion Rd. Dry Ridge, KY 41035", "8707 Camp Ernst Road Union, KY 41091", "7812 East Bend Road Burlington, KY 41005",
                "12449 Decoursey Pike Morning View, KY 41063", "3246 Augusta-Berlin Road Brooksville, KY 41004", "5350 Raymond Road May's Lick, KY 41055", "4085 Ewing Road Ewing, KY 41039",
                "1069 Ruddles Mill Road Paris, KY 40361", "239 Lail Lane Paris, KY 40361", "180 Stone Road Georgetown, KY 40324", "2231 Houston Antioch Road Lexington, KY 40516",
                "1801 Alexandria Drive Lexington, KY 40504", "1396 Pinckard Pike Versailles, KY 40383", "1371 Beverly Lane Nicholasville, KY 40356",
                "4776 Old Boonesboro Road Winchester, KY 40391", "3925 Old Boonesboro Road Winchester, KY 40391", "11620 Main Street Jeffersonville, KY 40337",
                "2726 Osborne Road Mt. Sterling, KY 40353", "99 Union Road Beattyville, KY 41311", "1523 Hwy 119 North Whitesburg, KY 41815", "52 KY Route 3224 River, KY 41254",
                "2836 State Route 1 Greenup, KY 41144", "45 Katherine Lane Greenup, KY 41144", "1483 Big Run Road Wallingford, KY 41093", "430 Wallacetown Road Paint Lick, KY 40461",
                "9730 KY 136W Calhoun, KY 42327", "4818 Hwy 144 Owensboro, KY 42303", "88 Noe Lane Russellville, KY 42276", "59 Williams Cemetery Rd. Hodgenville, KY 42748",
                "1114 KY Hwy 829 Albany, KY 42602", "680 Dug Hill Rd. Elk Horn, KY 42733", "975 Frankfort Rd. Lawrenceburg, KY 40342", "164 Old Peonia Loop Clarkson, KY 42726"
        };



        // Add Markers for each market
        for(int i = 0; i < Lat.length; i++)
        {
            map.addMarker(new MarkerOptions()
                    .position(new LatLng(Lat[i], Lon[i]))
                    .title(Market[i])
                    .snippet(Address[i])
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));

        }




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
