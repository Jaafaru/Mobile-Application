package com.uum.databasetest;

import java.util.ArrayList;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


public class MainActivity extends Activity {

	EditText et1, et2;
	
	
	//DB name
   SQLiteDatabase db1 = null;
  //Table name
    private static String DBName = "dbtest";
    
    
    ListView tlist;
	ArrayList<String> results;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tlist =(ListView) findViewById(R.id.list1);
        
        et1 = (EditText) findViewById(R.id.editText1);

        et2 = (EditText) findViewById(R.id.editText2); //object creation bind
      //Instantiate sampleDB object
        db1 = this.openOrCreateDatabase(DBName, MODE_PRIVATE, null);
        
      
    }
   
    public void pressme(View v){
    	
    	String name = et1.getText().toString();
    	String matric = et2.getText().toString();
    	
        try{
        	
           
         
            //Create table using execSQL
            db1.execSQL("CREATE TABLE IF NOT EXISTS student(ID INTEGER PRIMARY KEY, NAME " 
            + "VARCHAR, MATRIC VARCHAR);");  //Declare a fill
            
            //Insert student data into table created

           db1.execSQL("INSERT INTO student(MATRIC,NAME) VALUES" + "('"+name+"', '"+matric+"');");
            Toast.makeText(getApplicationContext(), "Added Data", Toast.LENGTH_LONG).show();

            showData();
           
            
          
            
         
        	
        }
        catch (Exception e ) {
        	Toast.makeText(getApplicationContext(), "Data not added!!", Toast.LENGTH_LONG).show();
        }
    }
    
    
    private void showData() {
    	
		results = new ArrayList<String>();
		
		
	Cursor c = db1.rawQuery("SELECT * FROM student", null);
		
	String allText = "";
		
		//If Cursor is valid
		if (c != null ) {
			//Move cursor to first row
			if  (c.moveToFirst()) {
				do {
					//Get version from Cursor
					String name1 = c.getString(c.getColumnIndex("NAME"));
					String matric1 = c.getString(c.getColumnIndex("MATRIC"));
					allText = ""+name1+" " +matric1;
					results.add(allText);

				}while (c.moveToNext()); //Move to next row
			} 
		}
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, results);
		// Assign adapter to ListView
		tlist.setAdapter(adapter); 
	}
    
   
    
    
    
    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
